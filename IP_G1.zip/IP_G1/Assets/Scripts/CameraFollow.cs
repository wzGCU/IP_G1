﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public GameObject toFollow;
    public float distance = 8.0f;
    public bool moveRight = true;
    public bool moveLeft = true;
    public float endMark;
    public float beginMark;

    // Update is called once per frame

    public void FixedUpdate() 
    { 
        if (moveRight)
        {
            Vector3 position = this.transform.position;
            position.x = toFollow.transform.position.x + distance;
            this.transform.position = position;
        }
        if (this.transform.position.x > endMark)
        {
            
            moveRight = false;
        }

    }
    public void moveCameraLeft()
    {
        if (moveLeft)
        {
            Vector3 position = this.transform.position;
            position.x = toFollow.transform.position.x - distance;
            this.transform.position = position;
        }
        if (this.transform.position.x < beginMark)
        {
            
            moveLeft = false;
        }
    }
}
