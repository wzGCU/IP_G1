﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    public KeyCode moveRightKey = KeyCode.D;
    public KeyCode moveLeftKey = KeyCode.A;
    public KeyCode jumpKey = KeyCode.W;
    public float speed = 0.2f;
    float direction = 0.0f;
    float directiony = 0.0f;
	public float jumpforce = 5.0f;
    public bool isGrounded;
	public int lifes = 3;
	public Text lifesTextfield;
    bool untouchable = false;
    public float timeTillTouchable;
    public float BasicEnemyPushStrength = 2.0f;
    public Text counterText;
    float seconds, minutes;



    void TimeUpdater()
    {
        //Converts the Time
        minutes = (int)(Time.timeSinceLevelLoad / 60f);
        seconds = (int)(Time.timeSinceLevelLoad % 60f);
        //Displays the Time
        counterText.text = minutes.ToString("00") + ":" + seconds.ToString("00");
    }
    public void consumeLife()
	{
		lifes -= 1;
	}
	
    void DeathCheck()
    {
        Vector3 position = transform.localPosition;
        //Death by lost lifes
        if (lifes == 0)
        {
            Debug.Log("Player lost all lifes");
            SceneManager.LoadScene("Menu");
        }
        //Death by fall
        if (position.y <= -8)
        {
            Debug.Log("Player fell from height");
            SceneManager.LoadScene("Menu");
        }
    }
    void Update()
    {
        DeathCheck();
        TimeUpdater();
        lifesTextfield.text = lifes.ToString();
    }


    // Update is called once per frame
    void FixedUpdate()
    {
        
        bool isLeftPressed = Input.GetKey(moveLeftKey);
        bool isRightPressed = Input.GetKey(moveRightKey);
        bool isJumpPressed = Input.GetKey(jumpKey);

        Vector3 position = transform.localPosition;
        position.x += speed * direction;
        position.y += speed * directiony;
        transform.localPosition = position;

        
        if (isLeftPressed)
        {
            direction = -1.0f;
            transform.localEulerAngles = new Vector3(0, 180, 0);
            //CameraFollow.moveCameraLeft();
        }
        else if (isRightPressed)
        {
            direction = 1.0f;
            transform.localEulerAngles = new Vector3(0, 0, 0);
            //CameraFollow.moveCameraRight();
        }
        else
        {
            direction = 0.0f;
        }
        if (isJumpPressed && isGrounded == true)
        {
            gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector2(0f, jumpforce), ForceMode2D.Impulse);
        }

    }
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Ground")
        {
            isGrounded = true;
        }
		if (collision.collider.tag == "Enemy")
		{
            if (!untouchable) 
            {
                Debug.Log("player hit the enemy");
                consumeLife();
                pushBack(BasicEnemyPushStrength);
                StartCoroutine(untouchableTime());
            }
			
		}
    }

    void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.collider.tag == "Ground")
        {
            isGrounded = false;
        }
		
    }
    IEnumerator untouchableTime()
    {
        untouchable = true;
        Physics2D.IgnoreLayerCollision(9, 10, true);
        yield return new WaitForSeconds(timeTillTouchable);
        untouchable = false;
        Physics2D.IgnoreLayerCollision(9, 10, false);
    }
    public void pushBack(float knockbackStrength)
    {
        gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector2(knockbackStrength, 0f), ForceMode2D.Impulse);
    }
}
