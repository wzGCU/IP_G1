﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arm2 : MonoBehaviour
{

    public KeyCode punchKey = KeyCode.Q;
    bool goFront = false;
    bool goBack = false;
    bool canArm = true;
    public float armDistance = 3.0f;
    float tempArmDistance;
    public float smoothness = 0.25f;
    public float xFix = 0.25f;
    float tempXFix;
    public float waitFlySeconds = 0.5f;
    GameObject player;
    Vector3 locationInFrontOfPlayer;
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        tempArmDistance = armDistance;
        tempXFix = xFix;

    }

    IEnumerator Fly()
    {
        gameObject.tag = "Arm";
        goFront = true;
        yield return new WaitForSeconds(waitFlySeconds);
        goFront = false;
        goBack = true;
        gameObject.tag = "Untagged" ;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        bool isPunchPressed = Input.GetKey(punchKey);

        if (isPunchPressed && canArm)
        {
            StartCoroutine(Fly());
        }

        if (player.transform.rotation.eulerAngles.y == 180.0f)
        {
            armDistance = -tempArmDistance;
            xFix = -tempXFix;
        }

        if (player.transform.rotation.eulerAngles.y == 0.0f)
        {
            armDistance = tempArmDistance;
            xFix = tempXFix;
        }

        if (goFront)
        {
            Vector3 position = this.transform.position;
            position.x = Mathf.Lerp(this.transform.position.x, player.transform.position.x + armDistance, smoothness);
            this.transform.position = position;
        }

        if (goBack)
        {
            Vector3 position = this.transform.position;
            position.x = Mathf.Lerp(this.transform.position.x, player.transform.position.x + xFix, smoothness);
            this.transform.position = position;
        }

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.collider.tag == "Enemy")
        {
            Debug.Log("Destroyed by Arm");
            Destroy(collision.gameObject);
        }
        if (collision.collider.tag == "Player")
        {
            canArm = true;
        }
    }
    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.collider.tag == "Player")
        {
            canArm = false;
            goBack = false;
        }
    }

}
