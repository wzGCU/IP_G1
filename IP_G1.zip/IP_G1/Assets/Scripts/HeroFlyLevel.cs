﻿using System.Collections;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HeroFlyLevel : MonoBehaviour
{
    //Defining Variables
    public KeyCode moveUp = KeyCode.W;
    public KeyCode moveDown = KeyCode.S;
	public KeyCode speedUp = KeyCode.D;
	public KeyCode speedDown = KeyCode.A;
    bool canUp = true;
    bool canDown = true;
    public float speedHoriz = 0.15f;
    public static float HorizontalSpeed;
    public float speedVerti = 0.2f;
    float direction = 0.0f;
	public float maxHeight = 4.16f;
	public float minHeight = -4.0f;
	public Text counterText;
    float seconds, minutes;
	
    void FixedUpdate()
    {
        Vector3 position = transform.localPosition;
        position.x += speedHoriz;
        position.y += speedVerti * direction;
		if(position.y > maxHeight){
			canUp = false;
		} else{
			canUp = true;
		}
		if(position.y < minHeight){
			canDown = false;
		} else{
			canDown = true;
		}
        transform.localPosition = position;
    }
	void TimeUpdater()
	{
		//Converts the Time
		minutes = (int)(Time.timeSinceLevelLoad / 60f);
        seconds = (int)(Time.timeSinceLevelLoad % 60f);
        //Displays the Time
        counterText.text = minutes.ToString("00") + ":" + seconds.ToString("00");
	}
    void Update()
    {
        HorizontalSpeed = speedHoriz;
        bool upPressed = Input.GetKey(moveUp);
        bool downPressed = Input.GetKey(moveDown);
		bool speedUpPressed = Input.GetKey(speedUp);
		bool speedDownPressed = Input.GetKey(speedDown);
		TimeUpdater();
       
        if (upPressed && canUp)
        {
            direction = 1.0f;
        }
        else if (downPressed && canDown)
        {
            direction = -1.0f;
        }
        else
        {
            direction = 0.0f;
        }
		if (speedUpPressed){
			speedHoriz = 0.25f;
		}
		if (speedDownPressed){
			speedHoriz = 0.15f;
		}
    }
  
}