﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{

    public float speed = 1.0f;
    public float direction = 1.0f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector2 position = transform.localPosition;
        position.x += (speed * direction);
        transform.localPosition = position;

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Wall")
        {
            direction = -direction;
            transform.Rotate(0.0f, 180.0f, 0.0f, Space.Self);
        }
        if (collision.collider.tag == "Bullet")
        {
            if(this.gameObject.layer == 11)
            {
                Debug.Log("bullet hit strong enemy so he doesnt die yo");
            }
            if(this.gameObject.layer == 10)
            {
                Destroy(gameObject);
            }
            
        }
        if (collision.collider.tag == "Arm")
        {
            Destroy(gameObject);
        }

    }
}

